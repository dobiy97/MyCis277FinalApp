#include <iostream>
#include <iomanip>
using namespace std;

double apples, oranges, cherries, watermelons;
double bananas, pears;
double wallet;
float userchoice;

int main()
{
  cout << "What is your budget? ";
  cin >> wallet;

  while (wallet >= 0)
  {
    cout << "\n\n Welcome to the Store!\n\n";
    cout << "Menu:\n\n";
    cout << "1    Apples        $2" <<endl;
    cout << "2    Oranges       $3" <<endl;
    cout << "3    Cherries      $4" <<endl;
    cout << "4    Watermelons   $5" <<endl;
    cout << "5    Bananas       $4" <<endl;
    cout << "6    Pears         $3" <<endl; 
    
    cout << "You have\n" << apples << " Apples\n" << oranges << " Oranges\n" 
    << cherries << " Cherries\n"
    << watermelons << " Watermelons\n"
    << bananas << " Bananas\n"
    << pears << " Pears \n";

    cout << "Your available credit is $" << wallet << "\n\n";
    cout << "Type in the number that represents the fruit you want or enter 7 to check out."<< "\n\n";
    
    cin >> userchoice;

    if (userchoice == 1)
    {
      apples++;
      wallet = wallet - 2;
    }
    if (userchoice == 2)
    {
      oranges++;
      wallet = wallet - 3;
    }
    if (userchoice == 3)
    {
     cherries++;
      wallet = wallet - 4;
    }
    if (userchoice == 4)
    {
      watermelons++;
      wallet = wallet - 5;
    }
     if (userchoice == 5)
    {
      bananas++;
      wallet = wallet - 4;
    }
     if (userchoice == 6)
    {
      pears++;
      wallet = wallet - 3;
    }
    if (userchoice == 7)
    {
      cout << "\n Thank you for shopping with us!";
      cin.get();
      return 0;
    }
  }

  return 0;
}